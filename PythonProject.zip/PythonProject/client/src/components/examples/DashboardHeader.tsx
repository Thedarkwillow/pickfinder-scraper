import DashboardHeader from '../DashboardHeader';

export default function DashboardHeaderExample() {
  return <DashboardHeader bankroll={127.50} alertCount={3} />;
}
