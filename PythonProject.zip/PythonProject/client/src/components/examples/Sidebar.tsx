import Sidebar from '../Sidebar';

export default function SidebarExample() {
  return <Sidebar />;
}
